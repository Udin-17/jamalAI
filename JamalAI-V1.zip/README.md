# Jamal AI V1
Aplikasi Android personal AI assistant.

Saat ini:
- Chat UI Jetpack Compose
- Kotlin + Gradle
- Application ID: com.jamalai.app

Cara menjalankan:
1. Buka folder ini di Android Studio.
2. Gradle Sync.
3. Hubungkan HP Android atau gunakan emulator.
4. Tekan Run.

Tahap berikutnya:
- koneksi AI melalui backend aman
- voice input
- foto dan file
- memory
- tool/function calling
- integrasi Android
- konfirmasi untuk tindakan sensitif
