package com.jamalai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { JamalAIApp() }
    }
}

@Composable
fun JamalAIApp() {
    var input by remember { mutableStateOf("") }
    val messages = remember {
        mutableStateListOf(
            ChatMessage("Halo! Saya Jamal AI. Apa yang ingin Anda lakukan?", false)
        )
    }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Jamal AI") }) },
            bottomBar = {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Ketik perintah Anda...") },
                        shape = RoundedCornerShape(24.dp),
                        singleLine = true
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val command = input.trim()
                            if (command.isNotEmpty()) {
                                messages.add(ChatMessage(command, true))
                                messages.add(ChatMessage(
                                    "Perintah diterima. Jamal AI V1 siap dikembangkan dengan AI, suara, foto, file, dan integrasi Android.",
                                    false
                                ))
                                input = ""
                            }
                        },
                        shape = RoundedCornerShape(24.dp)
                    ) { Text("Kirim") }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { message ->
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = if (message.fromUser) Alignment.CenterEnd else Alignment.CenterStart
                    ) {
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            tonalElevation = 2.dp,
                            modifier = Modifier.widthIn(max = 330.dp)
                        ) {
                            Text(message.text, modifier = Modifier.padding(14.dp))
                        }
                    }
                }
            }
        }
    }
}
